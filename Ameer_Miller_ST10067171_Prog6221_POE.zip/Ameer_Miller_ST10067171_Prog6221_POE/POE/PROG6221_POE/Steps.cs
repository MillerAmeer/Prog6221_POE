﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE
{

    public class Steps
    {
        public string step {get;set;}

        public Steps(string Step)
        {
            step = Step; 
        }
    }
   

}
