# prog_p1
To access this application, you will need to use visual studio code. The link to my code that is uploaded on GitHub which can be accessed with the link below:

https://github.com/MillerAmeer/prog_p1/blob/master/prog_p1/Program.cs

Download the zip file and open the prog_p1. It�s a c# application. And run it through the terminal. And follow the program as follows.
