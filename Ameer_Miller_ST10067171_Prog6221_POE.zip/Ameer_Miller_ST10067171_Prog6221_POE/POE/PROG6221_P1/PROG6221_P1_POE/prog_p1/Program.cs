﻿
using System;

namespace RecipeApplication
{
    class MyRecipe
    {
        private string[] ingredients;
        private double[] quantities;
        private string[] units;
        private string[] Methods;

        public MyRecipe()
        {
            // Initialize empty arrays for ingredients, quantities, units, and steps
            ingredients = new string[0];
            quantities = new double[0];
            units = new string[0];
            Methods = new string[0];
        }

        public void EnterDetails()
        {
            // Prompt the user to enter the number of ingredients
            Console.Write("Please enter the number of ingredients you wish to use: ");
            int numIngredients = int.Parse(Console.ReadLine());

            // Initialize the arrays with the correct size
            ingredients = new string[numIngredients];
            quantities = new double[numIngredients];
            units = new string[numIngredients];

            // Prompt the user to enter the details for each ingredient
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"Please enter details for ingredient for your recipe: Number {i + 1}:");
                Console.Write($"Name of {i + 1} ingredient: ");
                ingredients[i] = Console.ReadLine();
                Console.Write("Quantity of ingredient: ");
                quantities[i] = double.Parse(Console.ReadLine());
                Console.Write("Unit of measurement: ");
                units[i] = Console.ReadLine();
            }

            // Prompt the user to enter the number of steps
            Console.Write("Enter the number of steps for the method: ");
            int numMethods = int.Parse(Console.ReadLine());

            // Initialize the steps array with the correct size
            Methods = new string[numMethods];

            // Prompt the user to enter the details for each step
            for (int i = 0; i < numMethods; i++)
            {
                Console.Write($"Enter step {i + 1}: ");
                Methods[i] = Console.ReadLine();
            }
            }
        //After inserting the data thats needed display recipe to view results
        public void DisplayRecipe()
        {
            // Display the ingredients and quantities
            Console.WriteLine("Ingredients:");
            for (int i = 0; i < ingredients.Length; i++)
            {
                Console.WriteLine($"- {quantities[i]} {units[i]} of {ingredients[i]}");
            }

            // Display the steps
            Console.WriteLine("Steps:");
            for (int i = 0; i < Methods.Length; i++)
            {
                Console.WriteLine($"- {Methods[i]}");
            }
            }

        public void ScaleQuantities(double factor)
        {
            // Multiply all the quantities by the scaling factor
            for (int i = 0; i < quantities.Length; i++)
            {
                quantities[i] *= factor;
            }
            }

        public void ResetQuantities()
        {
            // Reset all the quantities back to their normal value
            for (int i = 0; i < quantities.Length; i++)
            {
                quantities[i] /= 2;
            }
            }
        //After inserting the data thats needed display recipe to view results

        public void DiscardRecipe()
        {
            // Reset all the arrays to empty
            ingredients = new string[0];
            quantities = new double[0];
            units = new string[0];
            Methods = new string[0];
        }
        }
    //After inserting the data thats needed display recipe to view results

    class MyRecipeProgram
    {
        static void Main(string[] args)
        {
            MyRecipe recipe = new MyRecipe();
            while (true)
            {
                Console.WriteLine("Enter '1' to enter recipe details.");
                Console.WriteLine("Enter '2' to display recipe.");
                Console.WriteLine("Enter '3' to scale recipe.");
                Console.WriteLine("Enter '4' to reset quantities.");
                Console.WriteLine("Enter '5' to clear recipe.");
                Console.WriteLine("Enter '6' to exit.");
                int choice = 4 ;
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice) { 


                    case 1:
                    recipe.EnterDetails();
                    break;
                case 2:
                    recipe.DisplayRecipe();
                    break;
                case 3:
                    Console.Write("Enter the scaling factor (0.5, 2, or 3): ");
                    double factor = double.Parse(Console.ReadLine());
                    recipe.ScaleQuantities(factor);
                    break;
                case 4:
                    recipe.ResetQuantities();
                    break;
                case 5:
                    recipe.DiscardRecipe();
                    break;
                case 6:
                    Console.WriteLine("Exiting your recipes" +
                        "/n" +"Thank you...");
                    return;
                default:
                    Console.WriteLine("Invalid selection. " +
                       "/n" + "Please enter a valid selection.");
                    break;
                }
                }
                }
                }
                }
